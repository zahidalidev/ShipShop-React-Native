#ShipSHOP 

* UI/UX design https://www.figma.com/file/dDytCtuWyPXVXcMdOXNbH8/ShipShop-v0.1?node-id=0%3A1

![Screenshot_20211119-182608_Expo Go](https://user-images.githubusercontent.com/46484008/142630807-33873851-dff0-4cd4-b011-fd3bde3afe6c.jpg)
